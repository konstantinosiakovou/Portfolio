package com.example.menuexample;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;


public class MainActivity extends Activity {

	DrawerLayout mainLayout=null;
    ArrayList<Car> result=new ArrayList<Car>();
    TableLayout resultLayout=null;
    EditText name=null,brand=null,cost=null;
    EditText showRecords=null;
    Button insertRecord=null;
    Database db=null;
	LinearLayout l1=null;
	ListView list=null;
	int width=0,height=0;


	public class Database extends SQLiteOpenHelper {

		private Context mcontext;
		private SQLiteDatabase database;
		public Database(Context context, String name, SQLiteDatabase.CursorFactory factory,
						int version) {

			super(context, name, factory, version);
			mcontext=context;
			database=this.getWritableDatabase();
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL("create table autos(name text,brand text,cost double)");

		}
		public ArrayList<Car> getResults()
		{
			ArrayList<Car> x=new ArrayList<Car>();
			Cursor cursor=database.rawQuery("select * from autos",null);
			if(cursor.getCount()==0)
			{
				cursor.close();
				return null;
			}
			int nameindex=cursor.getColumnIndex("name");
			int brandindex=cursor.getColumnIndex("brand");
			int costindex=cursor.getColumnIndex("cost");
			cursor.moveToFirst();
			do
			{
				Car c;
				c=new Car(cursor.getString(nameindex),
						cursor.getString(brandindex),
						cursor.getDouble(costindex));
				x.add(c);
			}while(cursor.moveToNext());
			cursor.close();
			return x;

		}

		public void insert(String name,String brand,double cost)
		{
			database.execSQL("insert into autos(name,brand,cost) values('"+
					name+"','"+brand+"',"+cost+")");
		}
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			db.execSQL("drop table autos");
			onCreate(db);
		}

		public void clearData()
		{
			database.execSQL("delete from autos");
		}

	}


	public void makeHeader(String title)
	{
		LinearLayout header=new LinearLayout(this);
		l1.addView(header);
		header.setBackgroundColor(Color.BLUE);
		LinearLayout.LayoutParams hparams=(LinearLayout.LayoutParams)header.getLayoutParams();
		hparams.width=width;
		hparams.height=height/10;
		header.setLayoutParams(hparams);
		ImageView openDrawer=new ImageView(this);
		header.addView(openDrawer);
		TextView t=new TextView(this);
		header.addView(t);
		LinearLayout.LayoutParams oparams=(LinearLayout.LayoutParams)openDrawer.getLayoutParams();
		oparams.leftMargin=width/20;
		oparams.topMargin=hparams.height/10;
		oparams.width=width/10;
		oparams.height=hparams.height-2*oparams.topMargin;
		openDrawer.setLayoutParams(oparams);
		Bitmap b1=BitmapFactory.decodeResource(getResources(), R.drawable.menuopen);
		b1=b1.createScaledBitmap(b1, oparams.width, oparams.height, true);
		openDrawer.setImageBitmap(b1);
		openDrawer.setClickable(true);
		openDrawer.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View v) {
				if(mainLayout.isDrawerOpen(list)) mainLayout.closeDrawer(list);
			    else mainLayout.openDrawer(list);
			}

		});
		LinearLayout.LayoutParams tparams=(LinearLayout.LayoutParams)t.getLayoutParams();
		tparams.leftMargin=width/20;
		tparams.topMargin=hparams.height/10;
		t.setLayoutParams(tparams);
		t.setTextSize(24);
		t.setTextColor(Color.YELLOW);
		t.setText(title);
	}

	@SuppressLint("ResourceType")
    public void makeHome()
	{
		if(l1!=null)
		{
			l1.removeAllViews();
		}
	else
	{
		l1=new LinearLayout(this);
		mainLayout.addView(l1);
		l1.setId(100);
		l1.setOrientation(LinearLayout.VERTICAL);
		DrawerLayout.LayoutParams l1params=(DrawerLayout.LayoutParams)l1.getLayoutParams();
		l1params.height=height-height/40;
		l1params.width=width;
		l1.setLayoutParams(l1params);
		l1.setBackgroundColor(Color.DKGRAY);
	}
	}

	public void makeTab1()
	{
		makeHome();
		makeHeader("INSERT");


    }



	public void makeTab2()
	{
		makeHome();
		makeHeader("SHOW");

	}

	public void makeTab3()
	{
		makeHome();
		makeHeader("STATS");

	}



	public void makeList()
	{
		ArrayList<String> s=new ArrayList<String>();
		s.add("INSERT");
		s.add("SHOW");
		s.add("STATS");
		ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,s);
		list=new ListView(this);
		TextView padding=new TextView(this);
	    padding.setHeight(height/15);
	    list.addHeaderView(padding);
	    padding.setBackgroundColor(Color.BLUE);
	    padding.setTextColor(Color.YELLOW);
	    padding.setTextSize(20);
	    padding.setText("Make a choice");
	    padding.setGravity(Gravity.CENTER);
		list.setAdapter(adapter);
		mainLayout.addView(list);
		DrawerLayout.LayoutParams cparams=(DrawerLayout.LayoutParams)list.getLayoutParams();
		cparams.width=3*width/4;
		cparams.height=DrawerLayout.LayoutParams.MATCH_PARENT;
		cparams.gravity=Gravity.START;
		list.setLayoutParams(cparams);
		list.setAdapter(adapter);
		list.setBackgroundColor(Color.BLACK);
		list.setOnItemClickListener(new OnItemClickListener()
		{

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if(position==0) return ;
				if(position==1)
					makeTab1();
				else
				if(position==2)
					makeTab2();
				else
				if(position==3)
					makeTab3();
				mainLayout.closeDrawer(list);

			}

		});
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mainLayout=new DrawerLayout(this);
        mainLayout.setDrawerShadow(R.drawable.drawershadow, GravityCompat.START);
		this.setContentView(mainLayout);
		Display display = getWindowManager().getDefaultDisplay();
	    width = display.getWidth();
	    height = display.getHeight();
		makeTab1();
		makeTab2();
		makeTab3();
		makeList();


	}
}
