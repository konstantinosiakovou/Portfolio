package com.example.menuexample;

public class Car {
        public String name;
        public String brand;
        public double cost;
        public Car(String n,String b,double c)
        {
            name=n;
            brand=b;
            cost=c;
        }
}
