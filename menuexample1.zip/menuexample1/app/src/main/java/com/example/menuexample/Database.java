package com.example.menuexample;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;


    public class Database extends SQLiteOpenHelper {

        private Context mcontext;
        private SQLiteDatabase database;
        public Database(Context context, String name, SQLiteDatabase.CursorFactory factory,
                        int version) {

            super(context, name, factory, version);
            mcontext=context;
            database=this.getWritableDatabase();
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table autos(name text,brand text,cost double)");

        }
        public ArrayList<Car> getResults()
        {
            ArrayList<Car> x=new ArrayList<Car>();
            Cursor cursor=database.rawQuery("select * from autos",null);
            if(cursor.getCount()==0)
            {
                cursor.close();
                return null;
            }
            int nameindex=cursor.getColumnIndex("name");
            int brandindex=cursor.getColumnIndex("brand");
            int costindex=cursor.getColumnIndex("cost");
            cursor.moveToFirst();
            do
            {
                Car c;
                c=new Car(cursor.getString(nameindex),
                        cursor.getString(brandindex),
                        cursor.getDouble(costindex));
                x.add(c);
            }while(cursor.moveToNext());
            cursor.close();
            return x;

        }

        public void insert(String name,String brand,double cost)
        {
            database.execSQL("insert into autos(name,brand,cost) values('"+
                    name+"','"+brand+"',"+cost+")");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("drop table autos");
            onCreate(db);
        }

        public void clearData()
        {
            database.execSQL("delete from autos");
        }

    }


