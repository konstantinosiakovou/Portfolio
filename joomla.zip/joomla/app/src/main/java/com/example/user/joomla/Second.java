package com.example.user.joomla;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.LinearLayout;


public class Second extends Activity {
    LinearLayout mainLayout = null;
    WebView htmlView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        setContentView(mainLayout);
        htmlView=new WebView(this) ;
        mainLayout.addView(htmlView);
        htmlView.loadUrl("https://project.joomla.com");

    }
}
