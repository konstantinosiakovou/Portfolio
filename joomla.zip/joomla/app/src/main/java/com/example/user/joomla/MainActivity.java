package com.example.user.joomla;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


public class MainActivity extends Activity {

    final int code1 = 500;
    final int code2= 500;
    LinearLayout buttonLayout = null;
    TextView result = null;
    LinearLayout mainLayout = null;
    Button web = null;
    Button newsletter=null;
    ImageView icon=null;
    TextView name=null;
    TextView am=null;
    TextView surname=null;
    TextView informations=null;

    @Override
    protected void onActivityResult(int requestCode,
                                    int resultCode, Intent data) {
        if (requestCode == code1)
            result.setText("Return from web site");
        else if (requestCode == code2)
            result.setText("Return from newsletter");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainLayout = new LinearLayout(this);
        setContentView(mainLayout);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        buttonLayout = new LinearLayout(this);
        mainLayout.addView(buttonLayout);
        icon=new ImageView(this);
        icon.setImageResource(R.drawable.logo);
        mainLayout.addView(icon);
        web=new Button(this);
        informations=new TextView(this);
        informations.setHint("Student`s informations:");
        mainLayout.addView(informations);
        name=new TextView(this);
        name.setHint("Student`s name: Konstantinos");
        mainLayout.addView(name);
        surname=new TextView(this);
        surname.setHint("Student`s surname: Iakovou");
        mainLayout.addView(surname);
        am=new TextView(this);
        am.setHint("Student`s ID: 13593");
        mainLayout.addView(am);
        web.setText("Web Site");
        mainLayout.addView(web);
        newsletter=new Button(this);
        newsletter.setText("Newsletter");
        mainLayout.addView(newsletter);
        web.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder alertDialog = new
                        AlertDialog.Builder(MainActivity.this);
                alertDialog.setTitle("QUESTION");
                alertDialog.setMessage(
                        "Do you want to open web site?");
                alertDialog.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent I = new Intent(MainActivity.this, Second.class);
                                startActivity(I);
                                dialogInterface.cancel();
                            }
                        });
                alertDialog.setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {
                                dialogInterface.cancel();
                            }
                        });
                alertDialog.show();
            }

            });
        newsletter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder alertDialog = new
                        AlertDialog.Builder(MainActivity.this);
                alertDialog.setTitle("QUESTION");
                alertDialog.setMessage(
                        "Do you want to open newsletter?");
                alertDialog.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent I = new Intent(MainActivity.this, Third.class);
                                startActivity(I);
                                dialogInterface.cancel();
                            }
                        });
                alertDialog.setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {
                                dialogInterface.cancel();
                            }
                        });
                alertDialog.show();
            }
        });

        LinearLayout.LayoutParams webparams=
                (LinearLayout.LayoutParams)web.getLayoutParams();
        webparams.topMargin=100;
        webparams.bottomMargin=4;
        LinearLayout.LayoutParams newsletterparams=
                (LinearLayout.LayoutParams)newsletter.getLayoutParams();
        newsletterparams.bottomMargin=10;

    }

}












