package com.example.user.joomla;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import org.json.JSONObject;


public class Third extends Activity {
    LinearLayout mainLayout=null;
    EditText name=null,brand=null,cost=null;
    Button insertRecord=null,showRecords=null;
    Button orderbyname=null,orderbybrand=null,orderbycost=null;
    ArrayList<Car> result=new ArrayList<Car>();
    TableLayout resultLayout=null;
    Database db=null;

    LinearLayout jsonLayout=null;
    Button loadJSON=null,saveJSON=null;

    public void makeJSON()
    {
        jsonLayout=new LinearLayout(this);
        mainLayout.addView(jsonLayout);
        loadJSON=new Button(this);
        loadJSON.setText("LOAD JSON");
        jsonLayout.addView(loadJSON);
        loadJSON.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v) {
                AlertDialog.Builder alert = new
                        AlertDialog.Builder(MainActivity.this);
                alert.setTitle("Load FILE");
                alert.setMessage("Specify file name: ");
                final EditText input = new EditText(MainActivity.this);
                alert.setView(input);
                alert.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int whichButton)
                            {
                                String value = input.getText().toString();
                                File myfile=new File(
                                        Environment.getExternalStorageDirectory(),value);
                                try {
                                    BufferedReader br = new BufferedReader(
                                            new InputStreamReader(new
                                                    FileInputStream(myfile), "utf8"),65536);
                                    String line="";
                                    line=br.readLine();
                                    try {
                                        JSONArray x=new JSONArray(line);
                                        Log.d("TEST","I have read "+x);
                                        int i;
                                        db.clearData();
                                        for(i=0;i<x.length();i++)
                                        {
                                            JSONObject p=x.getJSONObject(i);
                                            String name=p.getString("name");
                                            String brand=p.getString("brand");
                                            double cost =p.getDouble("cost");
                                            db.insert(name, brand, cost);
                                        }
                                    } catch (JSONException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                    }
                                    br.close();

                                }catch(IOException e)
                                {
                                    Log.d("TEST",e.getMessage());
                                }
                            }});
                alert.setNegativeButton("Cancel", new
                        DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton)
                            {
                            }
                        });

                alert.show();
            }

        });
        saveJSON=new Button(this);
        saveJSON.setText("SAVE JSON");
        saveJSON.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v) {
                result=db.getResults();
                final JSONArray x=new JSONArray();
                int i;
                for(i=0;i<result.size();i++)
                {
                    JSONObject p=new JSONObject();
                    try {
                        p.put("name", result.get(i).name);
                        p.put("brand",result.get(i).brand);
                        p.put("cost", result.get(i).cost);
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    x.put(p);
                }
                String s=x.toString();
                AlertDialog.Builder alert = new
                        AlertDialog.Builder(MainActivity.this);
                alert.setTitle("Create FILE");
                alert.setMessage("Specify file name: ");
                final EditText input = new EditText(MainActivity.this);
                alert.setView(input);
                alert.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int whichButton)
                            {
                                String value = input.getText().toString();
                                File myfile=new File(
                                        Environment.getExternalStorageDirectory(),value);
                                try {
                                    Writer out = new BufferedWriter(new OutputStreamWriter(
                                            new FileOutputStream(myfile), "UTF8"));
                                    out.append(x.toString());
                                    out.flush();
                                    out.close();
                                    Log.d("TEST", "Write "+x);
                                }catch(IOException e)
                                {
                                    Log.d("TEST",e.getMessage());
                                }
                            }});
                alert.setNegativeButton("Cancel", new
                        DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton)
                            {
                            }
                        });

                alert.show();
            }


        });
        jsonLayout.addView(saveJSON);

    }

    public void makeInputs()
    {
        LinearLayout l1=new LinearLayout(this);
        mainLayout.addView(l1);
        name=new EditText(this);
        name.setHint("Car name");
        l1.addView(name);
        brand=new EditText(this);
        brand.setHint("Car brand");
        l1.addView(brand);
        cost=new EditText(this);
        cost.setHint("Car cost");
        l1.addView(cost);
    }
    public void makeButtons()
    {
        LinearLayout l2=new LinearLayout(this);
        mainLayout.addView(l2);
        insertRecord=new Button(this);
        insertRecord.setText("INSERT RECORD");
        l2.addView(insertRecord);
        showRecords=new Button(this);
        showRecords.setText("SHOW RECORDS");
        l2.addView(showRecords);
        insertRecord.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v) {
                db.insert(name.getText().toString(),
                        brand.getText().toString(),
                        Double.parseDouble(cost.getText().toString()));

            }

        });
        showRecords.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v) {
                result=db.getResults();
                updateTable();

            }

        });
    }

    public void makeTable()
    {
        resultLayout=new TableLayout(this);
        ScrollView scroll=new ScrollView(this);
        mainLayout.addView(scroll);
        scroll.addView(resultLayout);
        TableRow r1=new TableRow(this);
        resultLayout.addView(r1);
        orderbyname=new Button(this);
        orderbyname.setText("NAME");
        r1.addView(orderbyname);
        orderbybrand=new Button(this);
        orderbybrand.setText("BRAND");
        r1.addView(orderbybrand);
        orderbycost=new Button(this);
        orderbycost.setText("COST");
        r1.addView(orderbycost);
        orderbyname.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v) {
                int i,j;
                for(i=0;i<result.size();i++)
                {
                    for(j=0;j<result.size()-1;j++)
                    {
                        Car c1=result.get(j);
                        Car c2=result.get(j+1);
                        if(c1.name.compareTo(c2.name)<0)
                        {
                            result.set(j, c2);
                            result.set(j+1, c1);
                        }
                    }
                }
                updateTable();

            }

        });
        orderbybrand.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v) {
                int i,j;
                for(i=0;i<result.size();i++)
                {
                    for(j=0;j<result.size()-1;j++)
                    {
                        Car c1=result.get(j);
                        Car c2=result.get(j+1);
                        if(c1.brand.compareTo(c2.brand)<0)
                        {
                            result.set(j, c2);
                            result.set(j+1, c1);
                        }
                    }
                }
                updateTable();

            }

        });
        orderbycost.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v) {
                int i,j;
                for(i=0;i<result.size();i++)
                {
                    for(j=0;j<result.size()-1;j++)
                    {
                        Car c1=result.get(j);
                        Car c2=result.get(j+1);
                        if(c1.cost<c2.cost)
                        {
                            result.set(j, c2);
                            result.set(j+1, c1);
                        }
                    }
                }
                updateTable();

            }

        });

    }

    public void updateTable()
    {
        resultLayout.removeAllViews();
        makeTable();
        int i;
        for(i=0;i<result.size();i++)
        {
            Car c=result.get(i);
            TableRow r=new TableRow(this);
            resultLayout.addView(r);
            TextView t1,t2,t3;
            t1=new TextView(this);
            t1.setText(c.name);
            t2=new TextView(this);
            t2.setText(c.brand);
            t3=new TextView(this);
            t3.setText(""+c.cost);
            r.addView(t1);
            r.addView(t2);
            r.addView(t3);
            ImageView delimage=new ImageView(this);
            r.addView(delimage);
            delimage.setId(i);
            delimage.setImageResource(R.drawable.delete);
            delimage.setClickable(true);
            delimage.setOnClickListener(new OnClickListener()
            {

                @Override
                public void onClick(View v) {
                    String cardetails="Name: "+
                            result.get(v.getId()).name+
                            " Brand: "+
                            result.get(v.getId()).brand+
                            " Cost: "+
                            result.get(v.getId()).cost;
                    Log.d("TEST","Delete Car is "+cardetails);

                }

            });
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainLayout=new LinearLayout(this);
        setContentView(mainLayout);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        db=new Database(this, "cars.db", null, 2);
        makeInputs();
        makeButtons();
        makeJSON();
        makeTable();
    }

    /**
     * Created by User on 31/10/2017.
     */

    public static class email extends Third {

        public class Car {
            public String name;
            public String brand;
            public double cost;
            public Car(String n,String b,double c)
            {
                name=n;
                brand=b;
                cost=c;
            }
        }

    }

    public static class Database extends Third {
        private Context mcontext;
        private SQLiteDatabase database;
        public Database(Context context, String name, CursorFactory factory,
                        int version) {

            super(context, name, factory, version);
            mcontext=context;
            database=this.getWritableDatabase();
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table autos(name text,brand text,cost double)");

        }
        public ArrayList<Car> getResults()
        {
            ArrayList<Car> x=new ArrayList<Car>();
            Cursor cursor=database.rawQuery("select * from autos",null);
            if(cursor.getCount()==0)
            {
                cursor.close();
                return null;
            }
            int nameindex=cursor.getColumnIndex("name");
            int brandindex=cursor.getColumnIndex("brand");
            int costindex=cursor.getColumnIndex("cost");
            cursor.moveToFirst();
            do
            {
                Car c;
                c=new Car(cursor.getString(nameindex),
                        cursor.getString(brandindex),
                        cursor.getDouble(costindex));
                x.add(c);
            }while(cursor.moveToNext());
            cursor.close();
            return x;

        }

        public void insert(String name,String brand,double cost)
        {
            database.execSQL("insert into autos(name,brand,cost) values('"+
                    name+"','"+brand+"',"+cost+")");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("drop table autos");
            onCreate(db);
        }

        public void clearData()
        {
            database.execSQL("delete from autos");
        }

    }
}
