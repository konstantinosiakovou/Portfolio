package com.example.user.notebook;

public class Students {
    public String lessons;
    public String student;
    public String observations;
    public double grade;

    public Students(String n, String b, String o, double c)
    {
        lessons=n;
        student=b;
        observations=o;
        grade=c;

    }
}
