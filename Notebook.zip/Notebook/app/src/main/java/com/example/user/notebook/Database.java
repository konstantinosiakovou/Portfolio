package com.example.user.notebook;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;


public class Database extends SQLiteOpenHelper{

    private Context mcontext;
    private SQLiteDatabase database;
    public Database(Context context, String name, CursorFactory factory,
                    int version) {
        super(context, name, null, version);
        mcontext=context;
        database=this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table school(lessons text,student text,observations text,grade double)");
    }
    public ArrayList<Students> getResults()
    {
        ArrayList<Students> x= new ArrayList<Students>();
        Cursor cursor=database.rawQuery("select * from school",null);
        if(cursor.getCount()==0)
        {
            cursor.close();
            return x;
        }
        int lessonsindex=cursor.getColumnIndex("lessons");
        int studentindex=cursor.getColumnIndex("student");
        int observationsindex=cursor.getColumnIndex("observations");
        int gradeindex=cursor.getColumnIndex("grade");
        cursor.moveToFirst();
        do
        {
            Students c;
            c=new Students(cursor.getString(lessonsindex),
                    cursor.getString(studentindex),
                    cursor.getString(observationsindex),
                    cursor.getDouble(gradeindex));
            x.add(c);
        }while(cursor.moveToNext());
        cursor.close();
        return x;

    }
    public void delete(String lessons,String student, String observations, double grade)
    {
        database.execSQL("delete from school where lessons='"+lessons+"' and student='"+
                student+"'and observations='"+observations+"' and grade = "+grade);
    }

    public void insert(String lessons,String student, String observations, double grade)
    {
        database.execSQL("insert into school(lessons,student,observations,grade) values('"+
                lessons+"','"+student+"','"+observations+"',"+grade+")");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table school");
        onCreate(db);
    }

    public void clearData()
    {
        database.execSQL("delete from school");
    }

}
