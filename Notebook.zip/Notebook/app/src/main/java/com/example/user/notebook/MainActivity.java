package com.example.user.notebook;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;


public class MainActivity extends Activity {

    LinearLayout mainLayout=null;
    EditText lessons=null,student=null,grade=null,observations=null;
    ImageView icon=null;
    TextView informations=null;
    Button insertRecord=null,showRecords=null;
    ArrayList<Students> result= new ArrayList<>();
    TableLayout resultLayout=null;
    Database db=null;

    LinearLayout jsonLayout=null;
    Button loadJSON=null,saveJSON=null;

    public void makeJSON()
    {
        jsonLayout=new LinearLayout(this);
        mainLayout.addView(jsonLayout);
        loadJSON=new Button(this);
        loadJSON.setText("Load Json");
        jsonLayout.addView(loadJSON);
        loadJSON.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v) {
                AlertDialog.Builder alert = new
                        AlertDialog.Builder(MainActivity.this);
                alert.setTitle("Load FILE");
                alert.setMessage("Specify file name: ");
                final EditText input = new EditText(MainActivity.this);
                alert.setView(input);
                alert.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int whichButton)
                            {
                                String value = input.getText().toString();
                                File myfile=new File(
                                        Environment.getExternalStorageDirectory(),value);
                                try {
                                    BufferedReader br = new BufferedReader(
                                            new InputStreamReader(new
                                                    FileInputStream(myfile), "utf8"),65536);
                                    String line="";
                                    line=br.readLine();
                                    try {
                                        JSONArray x=new JSONArray(line);
                                        Log.d("TEST","I have read "+x);
                                        int i;
                                        db.clearData();
                                        for(i=0;i<x.length();i++)
                                        {
                                            JSONObject p=x.getJSONObject(i);
                                            String lessons=p.getString("lessons");
                                            String student=p.getString("student");
                                            String observations=p.getString("observations");
                                            double grade =p.getDouble("grade");
                                            db.insert(lessons,student,observations,grade);
                                        }
                                    } catch (JSONException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                    }
                                    br.close();

                                }catch(IOException e)
                                {
                                    Log.d("TEST",e.getMessage());
                                }
                            }});
                alert.setNegativeButton("Cancel", new
                        DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton)
                            {
                            }
                        });

                alert.show();
            }

        });
        saveJSON=new Button(this);
        saveJSON.setText("Save Json");
        saveJSON.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v) {
                result=db.getResults();
                final JSONArray x=new JSONArray();
                int i;
                for(i=0;i<result.size();i++)
                {
                    JSONObject p=new JSONObject();
                    try {
                        p.put("lessons", result.get(i).lessons);
                        p.put("student",result.get(i).student);
                        p.put("observations", result.get(i).observations);
                        p.put("grade", result.get(i).grade);
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    x.put(p);
                }
                String s=x.toString();
                AlertDialog.Builder alert = new
                        AlertDialog.Builder(MainActivity.this);
                alert.setTitle("Create file");
                alert.setMessage("Specify file name: ");
                final EditText input = new EditText(MainActivity.this);
                alert.setView(input);
                alert.setPositiveButton("ok",
                        new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int whichButton)
                            {
                                String value = input.getText().toString();
                                File myfile=new File(
                                        Environment.getExternalStorageDirectory(),value);
                                try {
                                    Writer out = new BufferedWriter(new OutputStreamWriter(
                                            new FileOutputStream(myfile), "UTF8"));
                                    out.append(x.toString());
                                    out.flush();
                                    out.close();
                                    Log.d("TEST", "Write "+x);
                                }catch(IOException e)
                                {
                                    Log.d("TEST",e.getMessage());
                                }
                            }});
                alert.setNegativeButton("Cancel", new
                        DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton)
                            {
                            }
                        });

                alert.show();
            }


        });
        jsonLayout.addView(saveJSON);

    }

    public void makeInfo()
    {
        icon=new ImageView(this);
        icon.setImageResource(R.drawable.logo);
        mainLayout.addView(icon);
        informations=new TextView(this);
        informations.setHint("Please insert student`s informations:");
        informations.setTextColor(Color.BLACK );
        mainLayout.addView(informations);

    }

    public void makeInputs()
    {
        LinearLayout l1=new LinearLayout(this);
        mainLayout.addView(l1);
        lessons=new EditText(this);
        lessons.setHint("lessons");
        l1.addView(lessons);
        student=new EditText(this);
        student.setHint("student");
        l1.addView(student);
        grade=new EditText(this);
        grade.setHint("grade");
        l1.addView(grade);
        observations=new EditText(this);
        observations.setHint("observations");
        l1.addView(observations);
    }
    public void makeButtons()
    {
        LinearLayout l2=new LinearLayout(this);
        mainLayout.addView(l2);
        insertRecord=new Button(this);
        insertRecord.setText("Insert Record");
        l2.addView(insertRecord);
        showRecords=new Button(this);
        showRecords.setText("Show Records");
        l2.addView(showRecords);
        insertRecord.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v) {
                db.insert(lessons.getText().toString(),
                        student.getText().toString(),
                        observations.getText().toString(),
                        Double.parseDouble(grade.getText().toString()));

            }

        });
        showRecords.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v) {
                result=db.getResults();
                updateTable();

            }

        });
    }
    public void makeTable() {
        resultLayout = new TableLayout(this);
        ScrollView scroll = new ScrollView(this);
        mainLayout.addView(scroll);
        scroll.addView(resultLayout);
    }

    public void updateTable()
    {
        resultLayout.removeAllViews();
        int i;
        for(i=0;i<result.size();i++)
        {
            Students c=result.get(i);
            TableRow r=new TableRow(this);
            resultLayout.addView(r);
            TextView t1,t2,t3,t4;
            t1=new TextView(this);
            t1.setText(c.lessons);
            t2=new TextView(this);
            t2.setText(c.student);
            t3=new TextView(this);
            t3.setText(c.observations);
            t4=new TextView(this);
            t4.setText(""+c.grade);
            r.addView(t1);
            r.addView(t2);
            r.addView(t3);
            r.addView(t4);
            ImageView delimage=new ImageView(this);
            r.addView(delimage);
            delimage.setId(i);
            delimage.setImageResource(R.drawable.remove);
            delimage.setClickable(true);
            delimage.setOnClickListener(new OnClickListener()
            {

                @Override
                public void onClick(View v) {

                    db.delete(result.get(v.getId()).lessons,
                            result.get(v.getId()).student,
                            result.get(v.getId()).observations,
                            result.get(v.getId()).grade);
                    result=db.getResults();
                    updateTable();
                }

            });
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainLayout=new LinearLayout(this);
        setContentView(mainLayout);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        db=new Database(this, "school.db", null, 2);
        makeInfo();
        makeInputs();
        makeButtons();
        makeTable();
        makeJSON();

    }
}

